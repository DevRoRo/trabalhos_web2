import { formidable } from 'formidable'
import { prisma } from '../app.js'
import path from 'path'
import { promises as fs } from 'fs'

export function showPublishInterface(req, res) {
    res.render('publish')
}

export function publishImage(req, res) {
    const form = formidable({
        uploadDir: `public/uploads/${req.session.username}/`,
        createDirsFromUploads: true,
        keepExtensions: true
    });

    form.parse(req, (err, fields, files) => {
        if (err) {
            next(err);
            return;
        }
        res.redirect("/")
    });
}

export async function getUserImages(req) {
    const username = req.session.username
    const uploadDir = path.relative('/', '/public/uploads/'+username)
    const images = await fs.readdir(uploadDir)
    return images
}

async function findUser(username) {
    try {
        const user = await prisma.user.findUnique({
            where: {
                username: username
            }
        })

        if(!user) {
            throw new Error("Usuário não encontrado")
        }

        return user

    } catch (error) {
        throw (error)
    }
}

export async function userAuthentication(req, res) {
    try {
        const { username, password } = req.body;

        const user = await findUser(username);

        if (user.password === password) {
            req.session.auth = true;
            req.session.username = user.username;
            res.redirect('/');
        } else {
            throw new Error("Senha incorreta")
        }

    } catch (error) {
        console.error(error);
        if(error.message == "Senha incorreta") {
            res.send('<h1>Senha incorreta.</h1><br><a href="/users/userLogin">Tente novamente</a>');

        } else if (error.message == "Usuário não encontrado") {
            res.send('<h1>Usuário não encontrado.</h1><br><a href="/users/userLogin">Tente novamente</a>');
        } else {
            res.status(500).send("Ocorreu um erro no servidor.");
        }
    }
}

export function userLogout(req, res) {
    req.session.auth = false
    res.redirect("/")
}

export function showAuthForm (req, res) {
    res.render('authScreen')
}

export function showLoginScreen(req, res) {
    res.render('loginScreen')
}

export const register = async (req, res) => {
    const { username, password } = req.body;
    try {
        const user = await prisma.user.create({
            data: { username, password },
        });
        res.redirect('/')
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};
export function showReqData(req, res) {
    req.session.auth = true
    req.session.abcd = 1234
    return res.json({
        rota: req.url,
        queryparams: req.query,
        method: req.method,
        ip: req.ip,
        session: {
            ...req.session,
            sessionId: req.sessionID,
            sessionAuth: req.session.auth 
        }
    })
}